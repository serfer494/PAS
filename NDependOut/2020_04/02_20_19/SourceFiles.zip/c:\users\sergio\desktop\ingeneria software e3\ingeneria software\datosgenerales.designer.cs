﻿namespace Ingeneria_Software
{
    partial class DatosGenerales
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtGenero = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtEstadoCivil = new System.Windows.Forms.TextBox();
            this.dtpFechaNac = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.txtEscolaridad = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtOcupacion = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txtTelefono = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.rtxtMotivos = new System.Windows.Forms.RichTextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.txtDiarrea = new System.Windows.Forms.TextBox();
            this.txtVomito = new System.Windows.Forms.TextBox();
            this.txtColitis = new System.Windows.Forms.TextBox();
            this.txtAnsiedad = new System.Windows.Forms.TextBox();
            this.txtGastritis = new System.Windows.Forms.TextBox();
            this.txtNauseas = new System.Windows.Forms.TextBox();
            this.txtEstrenimiento = new System.Windows.Forms.TextBox();
            this.txtDisfagia = new System.Windows.Forms.TextBox();
            this.txtDolorCabeza = new System.Windows.Forms.TextBox();
            this.txtFlatulencias = new System.Windows.Forms.TextBox();
            this.txtEnfermedad = new System.Windows.Forms.RichTextBox();
            this.txtMedicamentos = new System.Windows.Forms.RichTextBox();
            this.txtSuplementos = new System.Windows.Forms.RichTextBox();
            this.txtMasticacion = new System.Windows.Forms.TextBox();
            this.txtDiureticos = new System.Windows.Forms.RichTextBox();
            this.txtLaxantes = new System.Windows.Forms.RichTextBox();
            this.txtCirugia = new System.Windows.Forms.RichTextBox();
            this.btnAPAgregar = new System.Windows.Forms.Button();
            this.next = new System.Windows.Forms.Button();
            this.panelDatosGenerales = new System.Windows.Forms.Panel();
            this.btnDatosPersonalesMod = new System.Windows.Forms.Button();
            this.btnAPModificar = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Teal;
            this.label2.Location = new System.Drawing.Point(17, 83);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 18);
            this.label2.TabIndex = 2;
            this.label2.Text = "Nombre:";
            // 
            // txtNombre
            // 
            this.txtNombre.Location = new System.Drawing.Point(94, 84);
            this.txtNombre.MaxLength = 50;
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(176, 20);
            this.txtNombre.TabIndex = 3;
            this.txtNombre.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNombre_KeyPress);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Teal;
            this.label4.Location = new System.Drawing.Point(17, 113);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 18);
            this.label4.TabIndex = 6;
            this.label4.Text = "Genero:";
            // 
            // txtGenero
            // 
            this.txtGenero.Location = new System.Drawing.Point(94, 114);
            this.txtGenero.MaxLength = 10;
            this.txtGenero.Name = "txtGenero";
            this.txtGenero.Size = new System.Drawing.Size(100, 20);
            this.txtGenero.TabIndex = 7;
            this.txtGenero.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtGenero_KeyPress);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Teal;
            this.label5.Location = new System.Drawing.Point(17, 146);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(179, 18);
            this.label5.TabIndex = 8;
            this.label5.Text = "Fecha de nacimiento:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Teal;
            this.label6.Location = new System.Drawing.Point(226, 116);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(104, 18);
            this.label6.TabIndex = 9;
            this.label6.Text = "Estado civil:";
            // 
            // txtEstadoCivil
            // 
            this.txtEstadoCivil.Location = new System.Drawing.Point(336, 117);
            this.txtEstadoCivil.MaxLength = 10;
            this.txtEstadoCivil.Name = "txtEstadoCivil";
            this.txtEstadoCivil.Size = new System.Drawing.Size(100, 20);
            this.txtEstadoCivil.TabIndex = 10;
            this.txtEstadoCivil.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtEstadoCivil_KeyPress);
            // 
            // dtpFechaNac
            // 
            this.dtpFechaNac.Location = new System.Drawing.Point(223, 146);
            this.dtpFechaNac.Name = "dtpFechaNac";
            this.dtpFechaNac.Size = new System.Drawing.Size(213, 20);
            this.dtpFechaNac.TabIndex = 11;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Teal;
            this.label7.Location = new System.Drawing.Point(17, 178);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(108, 18);
            this.label7.TabIndex = 12;
            this.label7.Text = "Escolaridad:";
            // 
            // txtEscolaridad
            // 
            this.txtEscolaridad.Location = new System.Drawing.Point(124, 177);
            this.txtEscolaridad.MaxLength = 50;
            this.txtEscolaridad.Name = "txtEscolaridad";
            this.txtEscolaridad.Size = new System.Drawing.Size(100, 20);
            this.txtEscolaridad.TabIndex = 13;
            this.txtEscolaridad.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtEscolaridad_KeyPress);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Teal;
            this.label8.Location = new System.Drawing.Point(245, 179);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(100, 18);
            this.label8.TabIndex = 14;
            this.label8.Text = "Ocupacion:";
            // 
            // txtOcupacion
            // 
            this.txtOcupacion.Location = new System.Drawing.Point(336, 179);
            this.txtOcupacion.MaxLength = 50;
            this.txtOcupacion.Name = "txtOcupacion";
            this.txtOcupacion.Size = new System.Drawing.Size(100, 20);
            this.txtOcupacion.TabIndex = 15;
            this.txtOcupacion.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtOcupacion_KeyPress);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Teal;
            this.label9.Location = new System.Drawing.Point(17, 204);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(82, 18);
            this.label9.TabIndex = 16;
            this.label9.Text = "Telefono:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Teal;
            this.label10.Location = new System.Drawing.Point(237, 204);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(56, 18);
            this.label10.TabIndex = 17;
            this.label10.Text = "Email:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Teal;
            this.label12.Location = new System.Drawing.Point(17, 261);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(171, 18);
            this.label12.TabIndex = 19;
            this.label12.Text = "Motivos de consulta:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Teal;
            this.label13.Location = new System.Drawing.Point(144, 9);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(149, 18);
            this.label13.TabIndex = 20;
            this.label13.Text = "Datos Personales";
            // 
            // txtTelefono
            // 
            this.txtTelefono.Location = new System.Drawing.Point(105, 205);
            this.txtTelefono.MaxLength = 12;
            this.txtTelefono.Name = "txtTelefono";
            this.txtTelefono.Size = new System.Drawing.Size(126, 20);
            this.txtTelefono.TabIndex = 21;
            this.txtTelefono.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTelefono_KeyPress);
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(299, 205);
            this.txtEmail.MaxLength = 20;
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(137, 20);
            this.txtEmail.TabIndex = 22;
            this.txtEmail.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtEmail_KeyPress);
            // 
            // rtxtMotivos
            // 
            this.rtxtMotivos.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rtxtMotivos.Location = new System.Drawing.Point(20, 282);
            this.rtxtMotivos.MaxLength = 100;
            this.rtxtMotivos.Name = "rtxtMotivos";
            this.rtxtMotivos.Size = new System.Drawing.Size(416, 96);
            this.rtxtMotivos.TabIndex = 24;
            this.rtxtMotivos.Text = "";
            this.rtxtMotivos.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.rtxtMotivos_KeyPress);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.Location = new System.Drawing.Point(442, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(10, 520);
            this.panel1.TabIndex = 25;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Teal;
            this.label14.Location = new System.Drawing.Point(601, 12);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(219, 18);
            this.label14.TabIndex = 27;
            this.label14.Text = "Antecedentes Patologicos";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Teal;
            this.label15.Location = new System.Drawing.Point(473, 47);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(73, 18);
            this.label15.TabIndex = 28;
            this.label15.Text = "Diarrea:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Teal;
            this.label16.Location = new System.Drawing.Point(473, 73);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(68, 18);
            this.label16.TabIndex = 29;
            this.label16.Text = "Vomito:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Teal;
            this.label17.Location = new System.Drawing.Point(476, 102);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(62, 18);
            this.label17.TabIndex = 30;
            this.label17.Text = "Colitis:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Arial Rounded MT Bold", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.Teal;
            this.label18.Location = new System.Drawing.Point(465, 133);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(81, 17);
            this.label18.TabIndex = 31;
            this.label18.Text = "Ansiedad:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Teal;
            this.label19.Location = new System.Drawing.Point(465, 191);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(83, 18);
            this.label19.TabIndex = 32;
            this.label19.Text = "Nauseas:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.Teal;
            this.label20.Location = new System.Drawing.Point(465, 161);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(81, 18);
            this.label20.TabIndex = 33;
            this.label20.Text = "Gastritis:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.Teal;
            this.label21.Location = new System.Drawing.Point(622, 104);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(103, 15);
            this.label21.TabIndex = 34;
            this.label21.Text = "Estreñimiento:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.Teal;
            this.label22.Location = new System.Drawing.Point(622, 127);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(116, 15);
            this.label22.TabIndex = 35;
            this.label22.Text = "Dolor de cabeza:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.Teal;
            this.label23.Location = new System.Drawing.Point(622, 148);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(77, 18);
            this.label23.TabIndex = 36;
            this.label23.Text = "Disfagia:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.Teal;
            this.label24.Location = new System.Drawing.Point(626, 76);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(183, 15);
            this.label24.TabIndex = 37;
            this.label24.Text = "Problemas de masticacion:";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.ForeColor = System.Drawing.Color.Teal;
            this.label30.Location = new System.Drawing.Point(628, 47);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(110, 18);
            this.label30.TabIndex = 43;
            this.label30.Text = "Flatulencias:";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.ForeColor = System.Drawing.Color.Teal;
            this.label31.Location = new System.Drawing.Point(473, 282);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(110, 18);
            this.label31.TabIndex = 44;
            this.label31.Text = "Enfermedad:";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.ForeColor = System.Drawing.Color.Teal;
            this.label32.Location = new System.Drawing.Point(609, 280);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(129, 18);
            this.label32.TabIndex = 45;
            this.label32.Text = "Medicamentos:";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.ForeColor = System.Drawing.Color.Teal;
            this.label33.Location = new System.Drawing.Point(751, 282);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(117, 18);
            this.label33.TabIndex = 46;
            this.label33.Text = "Suplementos:";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.ForeColor = System.Drawing.Color.Teal;
            this.label34.Location = new System.Drawing.Point(613, 382);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(86, 18);
            this.label34.TabIndex = 47;
            this.label34.Text = "Laxantes:";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.ForeColor = System.Drawing.Color.Teal;
            this.label35.Location = new System.Drawing.Point(476, 380);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(95, 18);
            this.label35.TabIndex = 48;
            this.label35.Text = "Diureticos:";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.ForeColor = System.Drawing.Color.Teal;
            this.label36.Location = new System.Drawing.Point(751, 382);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(70, 18);
            this.label36.TabIndex = 49;
            this.label36.Text = "Cirugia:";
            // 
            // txtDiarrea
            // 
            this.txtDiarrea.Location = new System.Drawing.Point(545, 47);
            this.txtDiarrea.MaxLength = 10;
            this.txtDiarrea.Name = "txtDiarrea";
            this.txtDiarrea.Size = new System.Drawing.Size(60, 20);
            this.txtDiarrea.TabIndex = 50;
            this.txtDiarrea.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDiarrea_KeyPress);
            // 
            // txtVomito
            // 
            this.txtVomito.Location = new System.Drawing.Point(545, 74);
            this.txtVomito.MaxLength = 10;
            this.txtVomito.Name = "txtVomito";
            this.txtVomito.Size = new System.Drawing.Size(60, 20);
            this.txtVomito.TabIndex = 51;
            this.txtVomito.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtVomito_KeyPress);
            // 
            // txtColitis
            // 
            this.txtColitis.Location = new System.Drawing.Point(544, 103);
            this.txtColitis.MaxLength = 10;
            this.txtColitis.Name = "txtColitis";
            this.txtColitis.Size = new System.Drawing.Size(60, 20);
            this.txtColitis.TabIndex = 52;
            this.txtColitis.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtColitis_KeyPress);
            // 
            // txtAnsiedad
            // 
            this.txtAnsiedad.Location = new System.Drawing.Point(545, 133);
            this.txtAnsiedad.MaxLength = 10;
            this.txtAnsiedad.Name = "txtAnsiedad";
            this.txtAnsiedad.Size = new System.Drawing.Size(60, 20);
            this.txtAnsiedad.TabIndex = 53;
            this.txtAnsiedad.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAnsiedad_KeyPress);
            // 
            // txtGastritis
            // 
            this.txtGastritis.Location = new System.Drawing.Point(545, 159);
            this.txtGastritis.MaxLength = 10;
            this.txtGastritis.Name = "txtGastritis";
            this.txtGastritis.Size = new System.Drawing.Size(60, 20);
            this.txtGastritis.TabIndex = 54;
            this.txtGastritis.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtGastritis_KeyPress);
            // 
            // txtNauseas
            // 
            this.txtNauseas.Location = new System.Drawing.Point(544, 189);
            this.txtNauseas.MaxLength = 10;
            this.txtNauseas.Name = "txtNauseas";
            this.txtNauseas.Size = new System.Drawing.Size(60, 20);
            this.txtNauseas.TabIndex = 55;
            this.txtNauseas.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNauseas_KeyPress);
            // 
            // txtEstrenimiento
            // 
            this.txtEstrenimiento.Location = new System.Drawing.Point(808, 98);
            this.txtEstrenimiento.MaxLength = 10;
            this.txtEstrenimiento.Name = "txtEstrenimiento";
            this.txtEstrenimiento.Size = new System.Drawing.Size(60, 20);
            this.txtEstrenimiento.TabIndex = 56;
            this.txtEstrenimiento.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtEstrenimiento_KeyPress);
            // 
            // txtDisfagia
            // 
            this.txtDisfagia.Location = new System.Drawing.Point(808, 150);
            this.txtDisfagia.MaxLength = 10;
            this.txtDisfagia.Name = "txtDisfagia";
            this.txtDisfagia.Size = new System.Drawing.Size(60, 20);
            this.txtDisfagia.TabIndex = 57;
            this.txtDisfagia.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDisfagia_KeyPress);
            // 
            // txtDolorCabeza
            // 
            this.txtDolorCabeza.Location = new System.Drawing.Point(808, 124);
            this.txtDolorCabeza.MaxLength = 10;
            this.txtDolorCabeza.Name = "txtDolorCabeza";
            this.txtDolorCabeza.Size = new System.Drawing.Size(60, 20);
            this.txtDolorCabeza.TabIndex = 61;
            this.txtDolorCabeza.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDolorCabeza_KeyPress);
            // 
            // txtFlatulencias
            // 
            this.txtFlatulencias.Location = new System.Drawing.Point(808, 47);
            this.txtFlatulencias.MaxLength = 10;
            this.txtFlatulencias.Name = "txtFlatulencias";
            this.txtFlatulencias.Size = new System.Drawing.Size(60, 20);
            this.txtFlatulencias.TabIndex = 65;
            this.txtFlatulencias.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFlatulencias_KeyPress);
            // 
            // txtEnfermedad
            // 
            this.txtEnfermedad.Location = new System.Drawing.Point(461, 303);
            this.txtEnfermedad.MaxLength = 100;
            this.txtEnfermedad.Name = "txtEnfermedad";
            this.txtEnfermedad.Size = new System.Drawing.Size(118, 65);
            this.txtEnfermedad.TabIndex = 66;
            this.txtEnfermedad.Text = "";
            this.txtEnfermedad.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtEnfermedad_KeyPress);
            // 
            // txtMedicamentos
            // 
            this.txtMedicamentos.Location = new System.Drawing.Point(599, 301);
            this.txtMedicamentos.MaxLength = 100;
            this.txtMedicamentos.Name = "txtMedicamentos";
            this.txtMedicamentos.Size = new System.Drawing.Size(126, 67);
            this.txtMedicamentos.TabIndex = 67;
            this.txtMedicamentos.Text = "";
            this.txtMedicamentos.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtMedicamentos_KeyPress);
            // 
            // txtSuplementos
            // 
            this.txtSuplementos.Location = new System.Drawing.Point(742, 301);
            this.txtSuplementos.MaxLength = 100;
            this.txtSuplementos.Name = "txtSuplementos";
            this.txtSuplementos.Size = new System.Drawing.Size(126, 67);
            this.txtSuplementos.TabIndex = 68;
            this.txtSuplementos.Text = "";
            this.txtSuplementos.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSuplementos_KeyPress);
            // 
            // txtMasticacion
            // 
            this.txtMasticacion.Location = new System.Drawing.Point(808, 75);
            this.txtMasticacion.MaxLength = 10;
            this.txtMasticacion.Name = "txtMasticacion";
            this.txtMasticacion.Size = new System.Drawing.Size(60, 20);
            this.txtMasticacion.TabIndex = 69;
            this.txtMasticacion.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtMasticacion_KeyPress);
            // 
            // txtDiureticos
            // 
            this.txtDiureticos.Location = new System.Drawing.Point(461, 401);
            this.txtDiureticos.MaxLength = 100;
            this.txtDiureticos.Name = "txtDiureticos";
            this.txtDiureticos.Size = new System.Drawing.Size(118, 65);
            this.txtDiureticos.TabIndex = 70;
            this.txtDiureticos.Text = "";
            this.txtDiureticos.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDiureticos_KeyPress);
            // 
            // txtLaxantes
            // 
            this.txtLaxantes.Location = new System.Drawing.Point(599, 401);
            this.txtLaxantes.MaxLength = 100;
            this.txtLaxantes.Name = "txtLaxantes";
            this.txtLaxantes.Size = new System.Drawing.Size(118, 65);
            this.txtLaxantes.TabIndex = 71;
            this.txtLaxantes.Text = "";
            this.txtLaxantes.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtLaxantes_KeyPress);
            // 
            // txtCirugia
            // 
            this.txtCirugia.Location = new System.Drawing.Point(742, 401);
            this.txtCirugia.MaxLength = 100;
            this.txtCirugia.Name = "txtCirugia";
            this.txtCirugia.Size = new System.Drawing.Size(118, 65);
            this.txtCirugia.TabIndex = 72;
            this.txtCirugia.Text = "";
            this.txtCirugia.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCirugia_KeyPress);
            // 
            // btnAPAgregar
            // 
            this.btnAPAgregar.BackColor = System.Drawing.Color.Teal;
            this.btnAPAgregar.FlatAppearance.BorderSize = 0;
            this.btnAPAgregar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAPAgregar.Font = new System.Drawing.Font("Arial Rounded MT Bold", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAPAgregar.ForeColor = System.Drawing.Color.White;
            this.btnAPAgregar.Location = new System.Drawing.Point(483, 483);
            this.btnAPAgregar.Name = "btnAPAgregar";
            this.btnAPAgregar.Size = new System.Drawing.Size(96, 40);
            this.btnAPAgregar.TabIndex = 73;
            this.btnAPAgregar.Text = "Agregar";
            this.btnAPAgregar.UseVisualStyleBackColor = false;
            this.btnAPAgregar.Click += new System.EventHandler(this.btnAPAgregar_Click);
            // 
            // next
            // 
            this.next.BackColor = System.Drawing.Color.Teal;
            this.next.FlatAppearance.BorderSize = 0;
            this.next.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.next.Font = new System.Drawing.Font("Arial Rounded MT Bold", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.next.ForeColor = System.Drawing.Color.White;
            this.next.Location = new System.Drawing.Point(742, 483);
            this.next.Name = "next";
            this.next.Size = new System.Drawing.Size(118, 40);
            this.next.TabIndex = 74;
            this.next.Text = "Sig. Pagina";
            this.next.UseVisualStyleBackColor = false;
            this.next.Click += new System.EventHandler(this.next_Click);
            // 
            // panelDatosGenerales
            // 
            this.panelDatosGenerales.Location = new System.Drawing.Point(0, 0);
            this.panelDatosGenerales.Name = "panelDatosGenerales";
            this.panelDatosGenerales.Size = new System.Drawing.Size(884, 544);
            this.panelDatosGenerales.TabIndex = 75;
            this.panelDatosGenerales.Visible = false;
            // 
            // btnDatosPersonalesMod
            // 
            this.btnDatosPersonalesMod.BackColor = System.Drawing.Color.Teal;
            this.btnDatosPersonalesMod.FlatAppearance.BorderSize = 0;
            this.btnDatosPersonalesMod.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDatosPersonalesMod.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDatosPersonalesMod.ForeColor = System.Drawing.Color.White;
            this.btnDatosPersonalesMod.Location = new System.Drawing.Point(147, 448);
            this.btnDatosPersonalesMod.Name = "btnDatosPersonalesMod";
            this.btnDatosPersonalesMod.Size = new System.Drawing.Size(160, 40);
            this.btnDatosPersonalesMod.TabIndex = 76;
            this.btnDatosPersonalesMod.Text = "Modificar";
            this.btnDatosPersonalesMod.UseVisualStyleBackColor = false;
            this.btnDatosPersonalesMod.Click += new System.EventHandler(this.btnDatosPersonalesMod_Click);
            // 
            // btnAPModificar
            // 
            this.btnAPModificar.BackColor = System.Drawing.Color.Teal;
            this.btnAPModificar.FlatAppearance.BorderSize = 0;
            this.btnAPModificar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAPModificar.Font = new System.Drawing.Font("Arial Rounded MT Bold", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAPModificar.ForeColor = System.Drawing.Color.White;
            this.btnAPModificar.Location = new System.Drawing.Point(621, 483);
            this.btnAPModificar.Name = "btnAPModificar";
            this.btnAPModificar.Size = new System.Drawing.Size(96, 40);
            this.btnAPModificar.TabIndex = 77;
            this.btnAPModificar.Text = "Modificar";
            this.btnAPModificar.UseVisualStyleBackColor = false;
            this.btnAPModificar.Click += new System.EventHandler(this.button2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkRed;
            this.label1.Location = new System.Drawing.Point(-2, 84);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(13, 16);
            this.label1.TabIndex = 78;
            this.label1.Text = "*";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DarkRed;
            this.label3.Location = new System.Drawing.Point(-2, 117);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(13, 16);
            this.label3.TabIndex = 79;
            this.label3.Text = "*";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.DarkRed;
            this.label11.Location = new System.Drawing.Point(-2, 146);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(13, 16);
            this.label11.TabIndex = 80;
            this.label11.Text = "*";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.DarkRed;
            this.label25.Location = new System.Drawing.Point(207, 118);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(13, 16);
            this.label25.TabIndex = 81;
            this.label25.Text = "*";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.Color.DarkRed;
            this.label26.Location = new System.Drawing.Point(-2, 177);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(13, 16);
            this.label26.TabIndex = 82;
            this.label26.Text = "*";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.Color.DarkRed;
            this.label27.Location = new System.Drawing.Point(226, 181);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(13, 16);
            this.label27.TabIndex = 83;
            this.label27.Text = "*";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.DarkRed;
            this.label28.Location = new System.Drawing.Point(-2, 263);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(13, 16);
            this.label28.TabIndex = 84;
            this.label28.Text = "*";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.Color.DarkRed;
            this.label29.Location = new System.Drawing.Point(454, 51);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(13, 16);
            this.label29.TabIndex = 85;
            this.label29.Text = "*";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.ForeColor = System.Drawing.Color.DarkRed;
            this.label37.Location = new System.Drawing.Point(458, 76);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(13, 16);
            this.label37.TabIndex = 86;
            this.label37.Text = "*";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.ForeColor = System.Drawing.Color.DarkRed;
            this.label38.Location = new System.Drawing.Point(457, 102);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(13, 16);
            this.label38.TabIndex = 87;
            this.label38.Text = "*";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.ForeColor = System.Drawing.Color.DarkRed;
            this.label39.Location = new System.Drawing.Point(454, 133);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(13, 16);
            this.label39.TabIndex = 88;
            this.label39.Text = "*";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.ForeColor = System.Drawing.Color.DarkRed;
            this.label40.Location = new System.Drawing.Point(454, 161);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(13, 16);
            this.label40.TabIndex = 89;
            this.label40.Text = "*";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.ForeColor = System.Drawing.Color.DarkRed;
            this.label41.Location = new System.Drawing.Point(454, 193);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(13, 16);
            this.label41.TabIndex = 90;
            this.label41.Text = "*";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.ForeColor = System.Drawing.Color.DarkRed;
            this.label42.Location = new System.Drawing.Point(454, 284);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(13, 16);
            this.label42.TabIndex = 91;
            this.label42.Text = "*";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.ForeColor = System.Drawing.Color.DarkRed;
            this.label43.Location = new System.Drawing.Point(454, 382);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(13, 16);
            this.label43.TabIndex = 92;
            this.label43.Text = "*";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.ForeColor = System.Drawing.Color.DarkRed;
            this.label44.Location = new System.Drawing.Point(596, 282);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(13, 16);
            this.label44.TabIndex = 93;
            this.label44.Text = "*";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.ForeColor = System.Drawing.Color.DarkRed;
            this.label45.Location = new System.Drawing.Point(596, 382);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(13, 16);
            this.label45.TabIndex = 94;
            this.label45.Text = "*";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.ForeColor = System.Drawing.Color.DarkRed;
            this.label46.Location = new System.Drawing.Point(739, 282);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(13, 16);
            this.label46.TabIndex = 95;
            this.label46.Text = "*";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.ForeColor = System.Drawing.Color.DarkRed;
            this.label47.Location = new System.Drawing.Point(739, 384);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(13, 16);
            this.label47.TabIndex = 96;
            this.label47.Text = "*";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.ForeColor = System.Drawing.Color.DarkRed;
            this.label48.Location = new System.Drawing.Point(611, 47);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(13, 16);
            this.label48.TabIndex = 97;
            this.label48.Text = "*";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.ForeColor = System.Drawing.Color.DarkRed;
            this.label49.Location = new System.Drawing.Point(611, 75);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(13, 16);
            this.label49.TabIndex = 98;
            this.label49.Text = "*";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.ForeColor = System.Drawing.Color.DarkRed;
            this.label50.Location = new System.Drawing.Point(609, 104);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(13, 16);
            this.label50.TabIndex = 99;
            this.label50.Text = "*";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.ForeColor = System.Drawing.Color.DarkRed;
            this.label51.Location = new System.Drawing.Point(609, 128);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(13, 16);
            this.label51.TabIndex = 100;
            this.label51.Text = "*";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.ForeColor = System.Drawing.Color.DarkRed;
            this.label52.Location = new System.Drawing.Point(609, 148);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(13, 16);
            this.label52.TabIndex = 101;
            this.label52.Text = "*";
            // 
            // DatosGenerales
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(884, 544);
            this.Controls.Add(this.panelDatosGenerales);
            this.Controls.Add(this.next);
            this.Controls.Add(this.btnAPAgregar);
            this.Controls.Add(this.txtCirugia);
            this.Controls.Add(this.txtLaxantes);
            this.Controls.Add(this.txtDiureticos);
            this.Controls.Add(this.txtMasticacion);
            this.Controls.Add(this.txtSuplementos);
            this.Controls.Add(this.txtMedicamentos);
            this.Controls.Add(this.txtEnfermedad);
            this.Controls.Add(this.txtFlatulencias);
            this.Controls.Add(this.txtDolorCabeza);
            this.Controls.Add(this.txtDisfagia);
            this.Controls.Add(this.txtEstrenimiento);
            this.Controls.Add(this.txtNauseas);
            this.Controls.Add(this.txtGastritis);
            this.Controls.Add(this.txtAnsiedad);
            this.Controls.Add(this.txtColitis);
            this.Controls.Add(this.txtVomito);
            this.Controls.Add(this.txtDiarrea);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.rtxtMotivos);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.txtTelefono);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtOcupacion);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtEscolaridad);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.dtpFechaNac);
            this.Controls.Add(this.txtEstadoCivil);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtGenero);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtNombre);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnDatosPersonalesMod);
            this.Controls.Add(this.btnAPModificar);
            this.Controls.Add(this.label52);
            this.Controls.Add(this.label51);
            this.Controls.Add(this.label50);
            this.Controls.Add(this.label49);
            this.Controls.Add(this.label48);
            this.Controls.Add(this.label47);
            this.Controls.Add(this.label46);
            this.Controls.Add(this.label45);
            this.Controls.Add(this.label44);
            this.Controls.Add(this.label43);
            this.Controls.Add(this.label42);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "DatosGenerales";
            this.Text = "DatosGenerales";
            this.Load += new System.EventHandler(this.DatosGenerales_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtGenero;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtEstadoCivil;
        private System.Windows.Forms.DateTimePicker dtpFechaNac;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtEscolaridad;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtOcupacion;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtTelefono;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.RichTextBox rtxtMotivos;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox txtDiarrea;
        private System.Windows.Forms.TextBox txtVomito;
        private System.Windows.Forms.TextBox txtColitis;
        private System.Windows.Forms.TextBox txtAnsiedad;
        private System.Windows.Forms.TextBox txtGastritis;
        private System.Windows.Forms.TextBox txtNauseas;
        private System.Windows.Forms.TextBox txtEstrenimiento;
        private System.Windows.Forms.TextBox txtDisfagia;
        private System.Windows.Forms.TextBox txtDolorCabeza;
        private System.Windows.Forms.TextBox txtFlatulencias;
        private System.Windows.Forms.RichTextBox txtEnfermedad;
        private System.Windows.Forms.RichTextBox txtMedicamentos;
        private System.Windows.Forms.RichTextBox txtSuplementos;
        private System.Windows.Forms.TextBox txtMasticacion;
        private System.Windows.Forms.RichTextBox txtDiureticos;
        private System.Windows.Forms.RichTextBox txtLaxantes;
        private System.Windows.Forms.RichTextBox txtCirugia;
        private System.Windows.Forms.Button btnAPAgregar;
        private System.Windows.Forms.Button next;
        private System.Windows.Forms.Panel panelDatosGenerales;
        private System.Windows.Forms.Button btnDatosPersonalesMod;
        private System.Windows.Forms.Button btnAPModificar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
    }
}