﻿namespace Ingeneria_Software
{
    partial class Generales3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtComidasDia = new System.Windows.Forms.RichTextBox();
            this.txtQuienComida = new System.Windows.Forms.RichTextBox();
            this.txtComeFuera = new System.Windows.Forms.RichTextBox();
            this.txtAlimentosPref = new System.Windows.Forms.RichTextBox();
            this.txtAlergias = new System.Windows.Forms.RichTextBox();
            this.txtNotas = new System.Windows.Forms.RichTextBox();
            this.txtRecordatorio = new System.Windows.Forms.RichTextBox();
            this.btnAgregar = new System.Windows.Forms.Button();
            this.regre = new System.Windows.Forms.Button();
            this.panelGenerales3 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.txtAgua = new System.Windows.Forms.RichTextBox();
            this.btnModificar = new System.Windows.Forms.Button();
            this.label23 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Teal;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(188, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "Indicadores Dieteticos";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Teal;
            this.label2.Location = new System.Drawing.Point(36, 36);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(128, 18);
            this.label2.TabIndex = 1;
            this.label2.Text = "Comidas al dia:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Teal;
            this.label3.Location = new System.Drawing.Point(208, 36);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(173, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "Quien prepara su comida:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Teal;
            this.label4.Location = new System.Drawing.Point(413, 36);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(105, 18);
            this.label4.TabIndex = 3;
            this.label4.Text = "Come fuera:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Teal;
            this.label5.Location = new System.Drawing.Point(620, 33);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(178, 18);
            this.label5.TabIndex = 4;
            this.label5.Text = "Alimentos preferidos:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Teal;
            this.label6.Location = new System.Drawing.Point(211, 176);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(227, 15);
            this.label6.TabIndex = 5;
            this.label6.Text = "Alergias/ Intolerancias a comidas:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Teal;
            this.label8.Location = new System.Drawing.Point(454, 176);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(60, 18);
            this.label8.TabIndex = 7;
            this.label8.Text = "Notas:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Teal;
            this.label9.Location = new System.Drawing.Point(12, 310);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(193, 18);
            this.label9.TabIndex = 8;
            this.label9.Text = "Recordatorio 24 horas:";
            // 
            // txtComidasDia
            // 
            this.txtComidasDia.Location = new System.Drawing.Point(15, 57);
            this.txtComidasDia.MaxLength = 50;
            this.txtComidasDia.Name = "txtComidasDia";
            this.txtComidasDia.Size = new System.Drawing.Size(185, 84);
            this.txtComidasDia.TabIndex = 9;
            this.txtComidasDia.Text = "";
            this.txtComidasDia.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtComidasDia_KeyPress);
            // 
            // txtQuienComida
            // 
            this.txtQuienComida.Location = new System.Drawing.Point(211, 57);
            this.txtQuienComida.MaxLength = 20;
            this.txtQuienComida.Name = "txtQuienComida";
            this.txtQuienComida.Size = new System.Drawing.Size(185, 84);
            this.txtQuienComida.TabIndex = 10;
            this.txtQuienComida.Text = "";
            this.txtQuienComida.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQuienComida_KeyPress);
            // 
            // txtComeFuera
            // 
            this.txtComeFuera.Location = new System.Drawing.Point(416, 57);
            this.txtComeFuera.MaxLength = 10;
            this.txtComeFuera.Name = "txtComeFuera";
            this.txtComeFuera.Size = new System.Drawing.Size(185, 84);
            this.txtComeFuera.TabIndex = 11;
            this.txtComeFuera.Text = "";
            this.txtComeFuera.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtComeFuera_KeyPress);
            // 
            // txtAlimentosPref
            // 
            this.txtAlimentosPref.Location = new System.Drawing.Point(623, 57);
            this.txtAlimentosPref.MaxLength = 100;
            this.txtAlimentosPref.Name = "txtAlimentosPref";
            this.txtAlimentosPref.Size = new System.Drawing.Size(185, 84);
            this.txtAlimentosPref.TabIndex = 12;
            this.txtAlimentosPref.Text = "";
            this.txtAlimentosPref.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAlimentosPref_KeyPress);
            // 
            // txtAlergias
            // 
            this.txtAlergias.Location = new System.Drawing.Point(211, 194);
            this.txtAlergias.MaxLength = 50;
            this.txtAlergias.Name = "txtAlergias";
            this.txtAlergias.Size = new System.Drawing.Size(224, 96);
            this.txtAlergias.TabIndex = 14;
            this.txtAlergias.Text = "";
            this.txtAlergias.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAlergias_KeyPress);
            // 
            // txtNotas
            // 
            this.txtNotas.Location = new System.Drawing.Point(457, 197);
            this.txtNotas.MaxLength = 500;
            this.txtNotas.Name = "txtNotas";
            this.txtNotas.Size = new System.Drawing.Size(185, 96);
            this.txtNotas.TabIndex = 15;
            this.txtNotas.Text = "";
            this.txtNotas.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNotas_KeyPress);
            // 
            // txtRecordatorio
            // 
            this.txtRecordatorio.Location = new System.Drawing.Point(15, 331);
            this.txtRecordatorio.MaxLength = 500;
            this.txtRecordatorio.Name = "txtRecordatorio";
            this.txtRecordatorio.Size = new System.Drawing.Size(420, 96);
            this.txtRecordatorio.TabIndex = 16;
            this.txtRecordatorio.Text = "";
            this.txtRecordatorio.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtRecordatorio_KeyPress);
            // 
            // btnAgregar
            // 
            this.btnAgregar.BackColor = System.Drawing.Color.Teal;
            this.btnAgregar.FlatAppearance.BorderSize = 0;
            this.btnAgregar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAgregar.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAgregar.ForeColor = System.Drawing.Color.White;
            this.btnAgregar.Location = new System.Drawing.Point(482, 344);
            this.btnAgregar.Name = "btnAgregar";
            this.btnAgregar.Size = new System.Drawing.Size(160, 40);
            this.btnAgregar.TabIndex = 17;
            this.btnAgregar.Text = "Agregar";
            this.btnAgregar.UseVisualStyleBackColor = false;
            this.btnAgregar.Click += new System.EventHandler(this.dieteticos_Click);
            // 
            // regre
            // 
            this.regre.BackColor = System.Drawing.Color.Teal;
            this.regre.FlatAppearance.BorderSize = 0;
            this.regre.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.regre.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.regre.ForeColor = System.Drawing.Color.White;
            this.regre.Location = new System.Drawing.Point(673, 442);
            this.regre.Name = "regre";
            this.regre.Size = new System.Drawing.Size(160, 40);
            this.regre.TabIndex = 18;
            this.regre.Text = "Regresar";
            this.regre.UseVisualStyleBackColor = false;
            this.regre.Click += new System.EventHandler(this.regre_Click);
            // 
            // panelGenerales3
            // 
            this.panelGenerales3.BackColor = System.Drawing.Color.White;
            this.panelGenerales3.Location = new System.Drawing.Point(0, 0);
            this.panelGenerales3.Name = "panelGenerales3";
            this.panelGenerales3.Size = new System.Drawing.Size(884, 544);
            this.panelGenerales3.TabIndex = 19;
            this.panelGenerales3.Visible = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Teal;
            this.label7.Location = new System.Drawing.Point(27, 176);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(50, 18);
            this.label7.TabIndex = 6;
            this.label7.Text = "Agua";
            // 
            // txtAgua
            // 
            this.txtAgua.Location = new System.Drawing.Point(15, 194);
            this.txtAgua.MaxLength = 50;
            this.txtAgua.Name = "txtAgua";
            this.txtAgua.Size = new System.Drawing.Size(185, 96);
            this.txtAgua.TabIndex = 13;
            this.txtAgua.Text = "";
            this.txtAgua.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAgua_KeyPress);
            // 
            // btnModificar
            // 
            this.btnModificar.BackColor = System.Drawing.Color.Teal;
            this.btnModificar.FlatAppearance.BorderSize = 0;
            this.btnModificar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnModificar.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnModificar.ForeColor = System.Drawing.Color.White;
            this.btnModificar.Location = new System.Drawing.Point(673, 344);
            this.btnModificar.Name = "btnModificar";
            this.btnModificar.Size = new System.Drawing.Size(160, 40);
            this.btnModificar.TabIndex = 20;
            this.btnModificar.Text = "Modificar";
            this.btnModificar.UseVisualStyleBackColor = false;
            this.btnModificar.Click += new System.EventHandler(this.btnModificar_Click);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.DarkRed;
            this.label23.Location = new System.Drawing.Point(12, 38);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(13, 16);
            this.label23.TabIndex = 59;
            this.label23.Text = "*";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.DarkRed;
            this.label10.Location = new System.Drawing.Point(192, 38);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(13, 16);
            this.label10.TabIndex = 60;
            this.label10.Text = "*";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.DarkRed;
            this.label11.Location = new System.Drawing.Point(394, 38);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(13, 16);
            this.label11.TabIndex = 61;
            this.label11.Text = "*";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.DarkRed;
            this.label12.Location = new System.Drawing.Point(588, 33);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(13, 16);
            this.label12.TabIndex = 62;
            this.label12.Text = "*";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.DarkRed;
            this.label13.Location = new System.Drawing.Point(192, 176);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(13, 16);
            this.label13.TabIndex = 63;
            this.label13.Text = "*";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.DarkRed;
            this.label14.Location = new System.Drawing.Point(12, 178);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(13, 16);
            this.label14.TabIndex = 64;
            this.label14.Text = "*";
            // 
            // Generales3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(868, 505);
            this.Controls.Add(this.panelGenerales3);
            this.Controls.Add(this.regre);
            this.Controls.Add(this.btnAgregar);
            this.Controls.Add(this.txtRecordatorio);
            this.Controls.Add(this.txtNotas);
            this.Controls.Add(this.txtAlergias);
            this.Controls.Add(this.txtAgua);
            this.Controls.Add(this.txtAlimentosPref);
            this.Controls.Add(this.txtComeFuera);
            this.Controls.Add(this.txtQuienComida);
            this.Controls.Add(this.txtComidasDia);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnModificar);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label23);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Generales3";
            this.Text = "Generales3";
            this.Load += new System.EventHandler(this.Generales3_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.RichTextBox txtComidasDia;
        private System.Windows.Forms.RichTextBox txtQuienComida;
        private System.Windows.Forms.RichTextBox txtComeFuera;
        private System.Windows.Forms.RichTextBox txtAlimentosPref;
        private System.Windows.Forms.RichTextBox txtAlergias;
        private System.Windows.Forms.RichTextBox txtNotas;
        private System.Windows.Forms.RichTextBox txtRecordatorio;
        private System.Windows.Forms.Button btnAgregar;
        private System.Windows.Forms.Button regre;
        private System.Windows.Forms.Panel panelGenerales3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.RichTextBox txtAgua;
        private System.Windows.Forms.Button btnModificar;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
    }
}