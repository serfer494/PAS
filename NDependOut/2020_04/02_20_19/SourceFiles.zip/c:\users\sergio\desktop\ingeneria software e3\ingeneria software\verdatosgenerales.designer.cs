﻿namespace Ingeneria_Software
{
    partial class VerDatosGenerales
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.label22 = new System.Windows.Forms.Label();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label53 = new System.Windows.Forms.Label();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label56 = new System.Windows.Forms.Label();
            this.textBox50 = new System.Windows.Forms.TextBox();
            this.label54 = new System.Windows.Forms.Label();
            this.textBox49 = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.textBox46 = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.textBox47 = new System.Windows.Forms.TextBox();
            this.label52 = new System.Windows.Forms.Label();
            this.textBox48 = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.label47 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label63 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.label55 = new System.Windows.Forms.Label();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.label57 = new System.Windows.Forms.Label();
            this.textBox51 = new System.Windows.Forms.TextBox();
            this.label58 = new System.Windows.Forms.Label();
            this.textBox52 = new System.Windows.Forms.TextBox();
            this.label59 = new System.Windows.Forms.Label();
            this.textBox53 = new System.Windows.Forms.TextBox();
            this.label60 = new System.Windows.Forms.Label();
            this.textBox54 = new System.Windows.Forms.TextBox();
            this.label61 = new System.Windows.Forms.Label();
            this.textBox55 = new System.Windows.Forms.TextBox();
            this.label62 = new System.Windows.Forms.Label();
            this.textBox56 = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Cursor = System.Windows.Forms.Cursors.Default;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Location = new System.Drawing.Point(294, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Datos Personales";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(799, 21);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(131, 13);
            this.label6.TabIndex = 3;
            this.label6.Text = "Antecedentes Patologicos";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 49);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(553, 67);
            this.dataGridView1.TabIndex = 0;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(420, 85);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(109, 20);
            this.textBox5.TabIndex = 86;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(301, 88);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(65, 13);
            this.label11.TabIndex = 87;
            this.label11.Text = "Escolaridad:";
            this.label11.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(16, 88);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(64, 13);
            this.label12.TabIndex = 85;
            this.label12.Text = "Estado civil:";
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(82, 120);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(211, 20);
            this.textBox8.TabIndex = 88;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(82, 85);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(213, 20);
            this.textBox6.TabIndex = 84;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(16, 123);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 13);
            this.label4.TabIndex = 89;
            this.label4.Text = "Ocupacion:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(299, 54);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(113, 13);
            this.label8.TabIndex = 83;
            this.label8.Text = "Fecha De Nacimiento:";
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(420, 120);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(109, 20);
            this.textBox7.TabIndex = 90;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(420, 51);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(109, 20);
            this.textBox3.TabIndex = 82;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(301, 123);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 13);
            this.label3.TabIndex = 91;
            this.label3.Text = "Telefono:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(301, 22);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(35, 13);
            this.label9.TabIndex = 81;
            this.label9.Text = "Edad:";
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(82, 155);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(211, 20);
            this.textBox10.TabIndex = 92;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(420, 22);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(109, 20);
            this.textBox4.TabIndex = 80;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(16, 158);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(38, 13);
            this.label13.TabIndex = 93;
            this.label13.Text = "E-mail:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(16, 54);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(47, 13);
            this.label7.TabIndex = 79;
            this.label7.Text = "Apellido:";
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(420, 155);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(109, 20);
            this.textBox9.TabIndex = 94;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(82, 51);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(211, 20);
            this.textBox2.TabIndex = 78;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(301, 158);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 13);
            this.label5.TabIndex = 95;
            this.label5.Text = "Horarios:";
            this.label5.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 13);
            this.label2.TabIndex = 77;
            this.label2.Text = "Nombre:";
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(19, 211);
            this.textBox11.Multiline = true;
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(430, 51);
            this.textBox11.TabIndex = 96;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(82, 19);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(121, 20);
            this.textBox1.TabIndex = 76;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(16, 192);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(103, 13);
            this.label14.TabIndex = 97;
            this.label14.Text = "Motivo De Consulta:";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(463, 224);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 28);
            this.button1.TabIndex = 3;
            this.button1.Text = "Modificar";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.textBox11);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.textBox2);
            this.groupBox1.Controls.Add(this.textBox9);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.textBox4);
            this.groupBox1.Controls.Add(this.textBox10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.textBox3);
            this.groupBox1.Controls.Add(this.textBox7);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.textBox6);
            this.groupBox1.Controls.Add(this.textBox8);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.textBox5);
            this.groupBox1.Location = new System.Drawing.Point(21, 122);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(544, 278);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Modificar";
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(594, 49);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(555, 67);
            this.dataGridView2.TabIndex = 4;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(24, 138);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(54, 13);
            this.label22.TabIndex = 120;
            this.label22.Text = "Ansiedad:";
            this.label22.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(428, 135);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(109, 20);
            this.textBox18.TabIndex = 121;
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(160, 135);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(109, 20);
            this.textBox19.TabIndex = 119;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(309, 138);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(88, 13);
            this.label21.TabIndex = 122;
            this.label21.Text = "Dolor de cabeza:";
            this.label21.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(308, 101);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(73, 13);
            this.label18.TabIndex = 118;
            this.label18.Text = "Estreñimiento:";
            this.label18.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(162, 176);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(109, 20);
            this.textBox27.TabIndex = 123;
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(427, 98);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(109, 20);
            this.textBox15.TabIndex = 117;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(26, 179);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(48, 13);
            this.label31.TabIndex = 124;
            this.label31.Text = "Disfagia:";
            this.label31.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(308, 66);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(52, 13);
            this.label19.TabIndex = 116;
            this.label19.Text = "Nauseas:";
            this.label19.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(162, 211);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(109, 20);
            this.textBox26.TabIndex = 125;
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(427, 63);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(109, 20);
            this.textBox16.TabIndex = 115;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(24, 214);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(133, 13);
            this.label30.TabIndex = 126;
            this.label30.Text = "Problemas de masticación:";
            this.label30.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(308, 31);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(47, 13);
            this.label20.TabIndex = 114;
            this.label20.Text = "Gastritis:";
            this.label20.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(162, 246);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(109, 20);
            this.textBox25.TabIndex = 127;
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(427, 28);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(109, 20);
            this.textBox17.TabIndex = 113;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(26, 249);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(46, 13);
            this.label29.TabIndex = 128;
            this.label29.Text = "Agruras:";
            this.label29.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(23, 101);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(37, 13);
            this.label15.TabIndex = 112;
            this.label15.Text = "Colitis:";
            this.label15.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(430, 176);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(109, 20);
            this.textBox24.TabIndex = 129;
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(159, 98);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(109, 20);
            this.textBox12.TabIndex = 111;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(311, 179);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(119, 13);
            this.label28.TabIndex = 130;
            this.label28.Text = "Disminución del apetito:";
            this.label28.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(23, 66);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(42, 13);
            this.label16.TabIndex = 110;
            this.label16.Text = "Vomito:";
            this.label16.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(430, 211);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(109, 20);
            this.textBox23.TabIndex = 131;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(159, 63);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(109, 20);
            this.textBox13.TabIndex = 109;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(311, 214);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(104, 13);
            this.label27.TabIndex = 132;
            this.label27.Text = "Aumento del apetito:";
            this.label27.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(23, 31);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(44, 13);
            this.label17.TabIndex = 108;
            this.label17.Text = "Diarrea:";
            this.label17.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(430, 246);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(109, 20);
            this.textBox22.TabIndex = 133;
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(159, 28);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(109, 20);
            this.textBox14.TabIndex = 107;
            // 
            // label26
            // 
            this.label26.Location = new System.Drawing.Point(308, 246);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(103, 37);
            this.label26.TabIndex = 134;
            this.label26.Text = "Inflamación/Dolor abdominal:";
            this.label26.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // textBox37
            // 
            this.textBox37.Location = new System.Drawing.Point(162, 287);
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(109, 20);
            this.textBox37.TabIndex = 142;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(36, 287);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(52, 13);
            this.label41.TabIndex = 143;
            this.label41.Text = "Diabetes:";
            this.label41.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // textBox36
            // 
            this.textBox36.Location = new System.Drawing.Point(162, 322);
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(109, 20);
            this.textBox36.TabIndex = 144;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(36, 322);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(44, 13);
            this.label40.TabIndex = 145;
            this.label40.Text = "Cáncer:";
            this.label40.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // textBox35
            // 
            this.textBox35.Location = new System.Drawing.Point(430, 287);
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(109, 20);
            this.textBox35.TabIndex = 146;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(311, 287);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(55, 13);
            this.label39.TabIndex = 147;
            this.label39.Text = "Obesidad:";
            this.label39.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // textBox34
            // 
            this.textBox34.Location = new System.Drawing.Point(430, 322);
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(109, 20);
            this.textBox34.TabIndex = 148;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(311, 322);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(52, 13);
            this.label38.TabIndex = 149;
            this.label38.Text = "Nauseas:";
            this.label38.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // textBox41
            // 
            this.textBox41.Location = new System.Drawing.Point(162, 361);
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(109, 20);
            this.textBox41.TabIndex = 150;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(36, 361);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(44, 13);
            this.label45.TabIndex = 151;
            this.label45.Text = "Diarrea:";
            this.label45.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // textBox40
            // 
            this.textBox40.Location = new System.Drawing.Point(162, 396);
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(109, 20);
            this.textBox40.TabIndex = 152;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(36, 396);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(42, 13);
            this.label44.TabIndex = 153;
            this.label44.Text = "Vomito:";
            this.label44.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // textBox39
            // 
            this.textBox39.Location = new System.Drawing.Point(430, 361);
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(109, 20);
            this.textBox39.TabIndex = 154;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(311, 361);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(47, 13);
            this.label43.TabIndex = 155;
            this.label43.Text = "Gastritis:";
            this.label43.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // textBox38
            // 
            this.textBox38.Location = new System.Drawing.Point(430, 396);
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new System.Drawing.Size(109, 20);
            this.textBox38.TabIndex = 156;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(311, 396);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(52, 13);
            this.label42.TabIndex = 157;
            this.label42.Text = "Nauseas:";
            this.label42.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(36, 427);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(30, 13);
            this.label46.TabIndex = 158;
            this.label46.Text = "Otra:";
            this.label46.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // textBox42
            // 
            this.textBox42.Location = new System.Drawing.Point(29, 443);
            this.textBox42.Multiline = true;
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(368, 68);
            this.textBox42.TabIndex = 159;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(442, 460);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 160;
            this.button2.Text = "Modificar";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button2);
            this.groupBox2.Controls.Add(this.textBox42);
            this.groupBox2.Controls.Add(this.label46);
            this.groupBox2.Controls.Add(this.label42);
            this.groupBox2.Controls.Add(this.textBox38);
            this.groupBox2.Controls.Add(this.label43);
            this.groupBox2.Controls.Add(this.textBox39);
            this.groupBox2.Controls.Add(this.label44);
            this.groupBox2.Controls.Add(this.textBox40);
            this.groupBox2.Controls.Add(this.label45);
            this.groupBox2.Controls.Add(this.textBox41);
            this.groupBox2.Controls.Add(this.label38);
            this.groupBox2.Controls.Add(this.textBox34);
            this.groupBox2.Controls.Add(this.label39);
            this.groupBox2.Controls.Add(this.textBox35);
            this.groupBox2.Controls.Add(this.label40);
            this.groupBox2.Controls.Add(this.textBox36);
            this.groupBox2.Controls.Add(this.label41);
            this.groupBox2.Controls.Add(this.textBox37);
            this.groupBox2.Controls.Add(this.label26);
            this.groupBox2.Controls.Add(this.textBox14);
            this.groupBox2.Controls.Add(this.textBox22);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.label27);
            this.groupBox2.Controls.Add(this.textBox13);
            this.groupBox2.Controls.Add(this.textBox23);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.label28);
            this.groupBox2.Controls.Add(this.textBox12);
            this.groupBox2.Controls.Add(this.textBox24);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label29);
            this.groupBox2.Controls.Add(this.textBox17);
            this.groupBox2.Controls.Add(this.textBox25);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.label30);
            this.groupBox2.Controls.Add(this.textBox16);
            this.groupBox2.Controls.Add(this.textBox26);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.label31);
            this.groupBox2.Controls.Add(this.textBox15);
            this.groupBox2.Controls.Add(this.textBox27);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Controls.Add(this.textBox19);
            this.groupBox2.Controls.Add(this.textBox18);
            this.groupBox2.Controls.Add(this.label22);
            this.groupBox2.Location = new System.Drawing.Point(594, 134);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(555, 528);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Modificar";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(1299, 21);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(151, 13);
            this.label53.TabIndex = 155;
            this.label53.Text = "Antecedentes No Patologicos:";
            this.label53.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(1157, 49);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.Size = new System.Drawing.Size(555, 67);
            this.dataGridView3.TabIndex = 156;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.button3);
            this.groupBox3.Controls.Add(this.label56);
            this.groupBox3.Controls.Add(this.textBox50);
            this.groupBox3.Controls.Add(this.label54);
            this.groupBox3.Controls.Add(this.textBox49);
            this.groupBox3.Controls.Add(this.label49);
            this.groupBox3.Controls.Add(this.textBox45);
            this.groupBox3.Controls.Add(this.label50);
            this.groupBox3.Controls.Add(this.textBox46);
            this.groupBox3.Controls.Add(this.label51);
            this.groupBox3.Controls.Add(this.textBox47);
            this.groupBox3.Controls.Add(this.label52);
            this.groupBox3.Controls.Add(this.textBox48);
            this.groupBox3.Location = new System.Drawing.Point(1155, 144);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(557, 129);
            this.groupBox3.TabIndex = 6;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Modificar";
            // 
            // label56
            // 
            this.label56.Location = new System.Drawing.Point(328, 47);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(65, 18);
            this.label56.TabIndex = 172;
            this.label56.Text = "Toximanias:";
            this.label56.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // textBox50
            // 
            this.textBox50.Location = new System.Drawing.Point(399, 44);
            this.textBox50.Name = "textBox50";
            this.textBox50.Size = new System.Drawing.Size(85, 20);
            this.textBox50.TabIndex = 171;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(367, 17);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(63, 13);
            this.label54.TabIndex = 170;
            this.label54.Text = "Frecuencia:";
            this.label54.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // textBox49
            // 
            this.textBox49.Location = new System.Drawing.Point(436, 14);
            this.textBox49.Name = "textBox49";
            this.textBox49.Size = new System.Drawing.Size(48, 20);
            this.textBox49.TabIndex = 169;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(172, 47);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(47, 13);
            this.label49.TabIndex = 168;
            this.label49.Text = "Tabaco:";
            this.label49.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // textBox45
            // 
            this.textBox45.Location = new System.Drawing.Point(225, 44);
            this.textBox45.Name = "textBox45";
            this.textBox45.Size = new System.Drawing.Size(78, 20);
            this.textBox45.TabIndex = 167;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(260, 17);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(56, 13);
            this.label50.TabIndex = 166;
            this.label50.Text = "Duracion :";
            this.label50.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // textBox46
            // 
            this.textBox46.Location = new System.Drawing.Point(320, 14);
            this.textBox46.Name = "textBox46";
            this.textBox46.Size = new System.Drawing.Size(41, 20);
            this.textBox46.TabIndex = 165;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(9, 52);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(45, 13);
            this.label51.TabIndex = 164;
            this.label51.Text = "Alcohol:";
            this.label51.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // textBox47
            // 
            this.textBox47.Location = new System.Drawing.Point(70, 45);
            this.textBox47.Name = "textBox47";
            this.textBox47.Size = new System.Drawing.Size(86, 20);
            this.textBox47.TabIndex = 163;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(9, 17);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(55, 13);
            this.label52.TabIndex = 162;
            this.label52.Text = "Ejercicios:";
            this.label52.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // textBox48
            // 
            this.textBox48.Location = new System.Drawing.Point(70, 14);
            this.textBox48.Name = "textBox48";
            this.textBox48.Size = new System.Drawing.Size(184, 20);
            this.textBox48.TabIndex = 161;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(228, 91);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 161;
            this.button3.Text = "Modificar";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // dataGridView4
            // 
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Location = new System.Drawing.Point(1155, 313);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.Size = new System.Drawing.Size(555, 67);
            this.dataGridView4.TabIndex = 157;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(1299, 280);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(123, 13);
            this.label47.TabIndex = 162;
            this.label47.Text = "Indicadores bioquimicos:";
            this.label47.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.button4);
            this.groupBox4.Controls.Add(this.label63);
            this.groupBox4.Controls.Add(this.label48);
            this.groupBox4.Controls.Add(this.textBox43);
            this.groupBox4.Controls.Add(this.label55);
            this.groupBox4.Controls.Add(this.textBox44);
            this.groupBox4.Controls.Add(this.label57);
            this.groupBox4.Controls.Add(this.textBox51);
            this.groupBox4.Controls.Add(this.label58);
            this.groupBox4.Controls.Add(this.textBox52);
            this.groupBox4.Controls.Add(this.label59);
            this.groupBox4.Controls.Add(this.textBox53);
            this.groupBox4.Controls.Add(this.label60);
            this.groupBox4.Controls.Add(this.textBox54);
            this.groupBox4.Controls.Add(this.label61);
            this.groupBox4.Controls.Add(this.textBox55);
            this.groupBox4.Controls.Add(this.label62);
            this.groupBox4.Controls.Add(this.textBox56);
            this.groupBox4.Location = new System.Drawing.Point(1157, 405);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(555, 257);
            this.groupBox4.TabIndex = 161;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Modificar";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(15, 25);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(68, 13);
            this.label63.TabIndex = 195;
            this.label63.Text = "Perfil lipidico:";
            this.label63.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(257, 172);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(81, 13);
            this.label48.TabIndex = 194;
            this.label48.Text = "Nitrogeo Ureico";
            this.label48.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // textBox43
            // 
            this.textBox43.Location = new System.Drawing.Point(376, 169);
            this.textBox43.Name = "textBox43";
            this.textBox43.Size = new System.Drawing.Size(109, 20);
            this.textBox43.TabIndex = 193;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(257, 137);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(87, 13);
            this.label55.TabIndex = 192;
            this.label55.Text = "Creatinina .mg/dl";
            this.label55.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // textBox44
            // 
            this.textBox44.Location = new System.Drawing.Point(376, 134);
            this.textBox44.Name = "textBox44";
            this.textBox44.Size = new System.Drawing.Size(109, 20);
            this.textBox44.TabIndex = 191;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(15, 172);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(79, 13);
            this.label57.TabIndex = 190;
            this.label57.Text = "Colesterol total:";
            this.label57.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // textBox51
            // 
            this.textBox51.Location = new System.Drawing.Point(108, 169);
            this.textBox51.Name = "textBox51";
            this.textBox51.Size = new System.Drawing.Size(109, 20);
            this.textBox51.TabIndex = 189;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(15, 137);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(56, 13);
            this.label58.TabIndex = 188;
            this.label58.Text = "Glicosuria:";
            this.label58.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // textBox52
            // 
            this.textBox52.Location = new System.Drawing.Point(108, 134);
            this.textBox52.Name = "textBox52";
            this.textBox52.Size = new System.Drawing.Size(109, 20);
            this.textBox52.TabIndex = 187;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(257, 98);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(33, 13);
            this.label59.TabIndex = 186;
            this.label59.Text = "Urea:";
            this.label59.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // textBox53
            // 
            this.textBox53.Location = new System.Drawing.Point(376, 95);
            this.textBox53.Name = "textBox53";
            this.textBox53.Size = new System.Drawing.Size(109, 20);
            this.textBox53.TabIndex = 185;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(257, 63);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(49, 13);
            this.label60.TabIndex = 184;
            this.label60.Text = "Glucosa:";
            this.label60.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // textBox54
            // 
            this.textBox54.Location = new System.Drawing.Point(376, 60);
            this.textBox54.Name = "textBox54";
            this.textBox54.Size = new System.Drawing.Size(109, 20);
            this.textBox54.TabIndex = 183;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(15, 98);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(72, 13);
            this.label61.TabIndex = 182;
            this.label61.Text = "Hemoglobina:";
            this.label61.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // textBox55
            // 
            this.textBox55.Location = new System.Drawing.Point(108, 95);
            this.textBox55.Name = "textBox55";
            this.textBox55.Size = new System.Drawing.Size(109, 20);
            this.textBox55.TabIndex = 181;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(15, 63);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(66, 13);
            this.label62.TabIndex = 180;
            this.label62.Text = "Trigliceridos:";
            this.label62.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // textBox56
            // 
            this.textBox56.Location = new System.Drawing.Point(108, 60);
            this.textBox56.Name = "textBox56";
            this.textBox56.Size = new System.Drawing.Size(109, 20);
            this.textBox56.TabIndex = 179;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(223, 228);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 161;
            this.button4.Text = "Modificar";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(1568, 685);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(121, 52);
            this.button5.TabIndex = 161;
            this.button5.Text = "Pagina 2";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // VerDatosGenerales
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1724, 749);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.label47);
            this.Controls.Add(this.dataGridView4);
            this.Controls.Add(this.dataGridView3);
            this.Controls.Add(this.label53);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "VerDatosGenerales";
            this.Text = "VerDatosGenerales";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.TextBox textBox50;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.TextBox textBox49;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.TextBox textBox45;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.TextBox textBox46;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.TextBox textBox47;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.TextBox textBox48;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox textBox43;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.TextBox textBox44;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.TextBox textBox51;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.TextBox textBox52;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.TextBox textBox53;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.TextBox textBox54;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.TextBox textBox55;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.TextBox textBox56;
        private System.Windows.Forms.Button button5;
    }
}