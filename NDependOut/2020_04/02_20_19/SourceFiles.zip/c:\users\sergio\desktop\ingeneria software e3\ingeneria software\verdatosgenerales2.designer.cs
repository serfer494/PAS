﻿namespace Ingeneria_Software
{
    partial class VerDatosGenerales2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.textBox64 = new System.Windows.Forms.TextBox();
            this.label71 = new System.Windows.Forms.Label();
            this.textBox63 = new System.Windows.Forms.TextBox();
            this.label70 = new System.Windows.Forms.Label();
            this.textBox62 = new System.Windows.Forms.TextBox();
            this.label69 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.textBox60 = new System.Windows.Forms.TextBox();
            this.label67 = new System.Windows.Forms.Label();
            this.textBox59 = new System.Windows.Forms.TextBox();
            this.label66 = new System.Windows.Forms.Label();
            this.textBox58 = new System.Windows.Forms.TextBox();
            this.label65 = new System.Windows.Forms.Label();
            this.textBox57 = new System.Windows.Forms.TextBox();
            this.label64 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox66 = new System.Windows.Forms.TextBox();
            this.label74 = new System.Windows.Forms.Label();
            this.textBox61 = new System.Windows.Forms.TextBox();
            this.label72 = new System.Windows.Forms.Label();
            this.textBox65 = new System.Windows.Forms.TextBox();
            this.label73 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.White;
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.textBox64);
            this.groupBox1.Controls.Add(this.label71);
            this.groupBox1.Controls.Add(this.textBox63);
            this.groupBox1.Controls.Add(this.label70);
            this.groupBox1.Controls.Add(this.textBox62);
            this.groupBox1.Controls.Add(this.label69);
            this.groupBox1.Controls.Add(this.label68);
            this.groupBox1.Controls.Add(this.textBox60);
            this.groupBox1.Controls.Add(this.label67);
            this.groupBox1.Controls.Add(this.textBox59);
            this.groupBox1.Controls.Add(this.label66);
            this.groupBox1.Controls.Add(this.textBox58);
            this.groupBox1.Controls.Add(this.label65);
            this.groupBox1.Controls.Add(this.textBox57);
            this.groupBox1.Controls.Add(this.label64);
            this.groupBox1.Location = new System.Drawing.Point(15, 155);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(543, 336);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Modificar";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(15, 53);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(543, 67);
            this.dataGridView1.TabIndex = 3;
            // 
            // textBox64
            // 
            this.textBox64.Location = new System.Drawing.Point(193, 186);
            this.textBox64.Multiline = true;
            this.textBox64.Name = "textBox64";
            this.textBox64.Size = new System.Drawing.Size(295, 49);
            this.textBox64.TabIndex = 209;
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(16, 280);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(38, 13);
            this.label71.TabIndex = 208;
            this.label71.Text = "Agua: ";
            this.label71.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // textBox63
            // 
            this.textBox63.Location = new System.Drawing.Point(193, 277);
            this.textBox63.Name = "textBox63";
            this.textBox63.Size = new System.Drawing.Size(293, 20);
            this.textBox63.TabIndex = 207;
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(16, 248);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(171, 13);
            this.label70.TabIndex = 206;
            this.label70.Text = "Alergias/ Intolerancias a alimentos:";
            this.label70.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // textBox62
            // 
            this.textBox62.Location = new System.Drawing.Point(193, 244);
            this.textBox62.Name = "textBox62";
            this.textBox62.Size = new System.Drawing.Size(295, 20);
            this.textBox62.TabIndex = 205;
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(16, 186);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(171, 13);
            this.label69.TabIndex = 204;
            this.label69.Text = "Alergias/ Intolerancias a alimentos:";
            this.label69.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(16, 123);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(113, 13);
            this.label68.TabIndex = 203;
            this.label68.Text = "Alimentos preferidos :  ";
            this.label68.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // textBox60
            // 
            this.textBox60.Location = new System.Drawing.Point(193, 120);
            this.textBox60.Multiline = true;
            this.textBox60.Name = "textBox60";
            this.textBox60.Size = new System.Drawing.Size(295, 49);
            this.textBox60.TabIndex = 202;
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(16, 84);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(108, 13);
            this.label67.TabIndex = 201;
            this.label67.Text = "Come fuera de casa: ";
            this.label67.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // textBox59
            // 
            this.textBox59.Location = new System.Drawing.Point(193, 81);
            this.textBox59.Name = "textBox59";
            this.textBox59.Size = new System.Drawing.Size(295, 20);
            this.textBox59.TabIndex = 200;
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(16, 47);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(146, 13);
            this.label66.TabIndex = 199;
            this.label66.Text = "Quien prepara sus alimentos: ";
            this.label66.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // textBox58
            // 
            this.textBox58.Location = new System.Drawing.Point(193, 44);
            this.textBox58.Name = "textBox58";
            this.textBox58.Size = new System.Drawing.Size(295, 20);
            this.textBox58.TabIndex = 198;
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(16, 16);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(151, 13);
            this.label65.TabIndex = 197;
            this.label65.Text = "Cuantas comidas hace al día: ";
            this.label65.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // textBox57
            // 
            this.textBox57.Location = new System.Drawing.Point(193, 13);
            this.textBox57.Name = "textBox57";
            this.textBox57.Size = new System.Drawing.Size(295, 20);
            this.textBox57.TabIndex = 196;
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(216, -17);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(115, 13);
            this.label64.TabIndex = 195;
            this.label64.Text = "Indicadores Dieteticos:";
            this.label64.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(115, 13);
            this.label1.TabIndex = 180;
            this.label1.Text = "Indicadores Dieteticos:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(297, 303);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 28);
            this.button1.TabIndex = 210;
            this.button1.Text = "Modificar";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.White;
            this.groupBox2.Controls.Add(this.button2);
            this.groupBox2.Controls.Add(this.textBox65);
            this.groupBox2.Controls.Add(this.label73);
            this.groupBox2.Controls.Add(this.textBox66);
            this.groupBox2.Controls.Add(this.label74);
            this.groupBox2.Controls.Add(this.textBox61);
            this.groupBox2.Controls.Add(this.label72);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Location = new System.Drawing.Point(564, 155);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(621, 523);
            this.groupBox2.TabIndex = 211;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Modificar";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(216, -17);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(115, 13);
            this.label9.TabIndex = 195;
            this.label9.Text = "Indicadores Dieteticos:";
            this.label9.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(564, 53);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(621, 67);
            this.dataGridView2.TabIndex = 212;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(561, 19);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(35, 13);
            this.label10.TabIndex = 213;
            this.label10.Text = "Notas";
            this.label10.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // textBox66
            // 
            this.textBox66.Location = new System.Drawing.Point(17, 299);
            this.textBox66.Multiline = true;
            this.textBox66.Name = "textBox66";
            this.textBox66.Size = new System.Drawing.Size(280, 199);
            this.textBox66.TabIndex = 206;
            // 
            // label74
            // 
            this.label74.Location = new System.Drawing.Point(14, 264);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(271, 36);
            this.label74.TabIndex = 205;
            this.label74.Text = "Describa un día con su rutina, horarios de comida, sueño, actividades y ejercicio" +
    "s que realiza:";
            this.label74.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox61
            // 
            this.textBox61.Location = new System.Drawing.Point(17, 55);
            this.textBox61.Multiline = true;
            this.textBox61.Name = "textBox61";
            this.textBox61.Size = new System.Drawing.Size(280, 190);
            this.textBox61.TabIndex = 204;
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(14, 29);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(130, 13);
            this.label72.TabIndex = 203;
            this.label72.Text = "Recordatorio de 24 horas:";
            this.label72.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // textBox65
            // 
            this.textBox65.Location = new System.Drawing.Point(314, 55);
            this.textBox65.Multiline = true;
            this.textBox65.Name = "textBox65";
            this.textBox65.Size = new System.Drawing.Size(280, 192);
            this.textBox65.TabIndex = 208;
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(311, 28);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(108, 13);
            this.label73.TabIndex = 207;
            this.label73.Text = "Notas/Interpretacion:";
            this.label73.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(416, 397);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 28);
            this.button2.TabIndex = 211;
            this.button2.Text = "Modificar";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(208, 625);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 28);
            this.button3.TabIndex = 212;
            this.button3.Text = "Salir";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // VerDatosGenerales2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1204, 689);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "VerDatosGenerales2";
            this.Text = "VerDatosGenerales2";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox textBox64;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.TextBox textBox63;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.TextBox textBox62;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.TextBox textBox60;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.TextBox textBox59;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.TextBox textBox58;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.TextBox textBox57;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox66;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.TextBox textBox61;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBox65;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Button button3;
    }
}