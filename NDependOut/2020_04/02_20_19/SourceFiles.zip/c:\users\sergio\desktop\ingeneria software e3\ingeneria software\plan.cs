﻿using Ingeneria_Software;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    /// <summary>
    /// En esta pantalla se crea el plan alimenticio.
    /// </summary>
    public partial class Plan : Form
    {
        public Plan()
        {
            InitializeComponent();
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            MenuPpal mp = new MenuPpal(1);
            this.Close();
            mp.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }
    }
}
